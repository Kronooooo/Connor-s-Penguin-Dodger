# Connor's Penguin Dodger
 
## PATCH NOTES

### v1.0.0.0
This is the first release of Space Penguins, with basic assets and no sound.

### v2.0.0.0
Added Music and SFX
Added settings to adjust volume
Added session top score
Can now move using arrow keys

## CREDITS
Penguin asset - https://caz-creates-games.itch.io/lil-penguin-character-sprite <br/>
Background and asteroid asset - https://pixelalek.itch.io/spaceship-simple-assets
Music - https://marc-davs.itch.io/ambient-space
Sound Effects - https://fallenblood.itch.io/50-sfx
